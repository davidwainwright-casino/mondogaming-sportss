<?php

class UserController extends Controller
{
}

?>
