<?php

return array(

    'headerHeight' => 35,
    'widgetWidth'  => 279,
    'widgetHeight' => 320,
);